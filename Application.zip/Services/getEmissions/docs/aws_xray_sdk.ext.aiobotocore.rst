aws\_xray\_sdk.ext.aiobotocore package
======================================

Submodules
----------

aws\_xray\_sdk.ext.aiobotocore.patch module
-------------------------------------------

.. automodule:: aws_xray_sdk.ext.aiobotocore.patch
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.ext.aiobotocore
    :members:
    :undoc-members:
    :show-inheritance:
