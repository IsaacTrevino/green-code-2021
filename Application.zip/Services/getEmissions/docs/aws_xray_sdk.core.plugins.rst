aws\_xray\_sdk.core.plugins package
===================================

Submodules
----------

aws\_xray\_sdk.core.plugins.ec2\_plugin module
----------------------------------------------

.. automodule:: aws_xray_sdk.core.plugins.ec2_plugin
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.plugins.ecs\_plugin module
----------------------------------------------

.. automodule:: aws_xray_sdk.core.plugins.ecs_plugin
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.plugins.elasticbeanstalk\_plugin module
-----------------------------------------------------------

.. automodule:: aws_xray_sdk.core.plugins.elasticbeanstalk_plugin
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.plugins.utils module
----------------------------------------

.. automodule:: aws_xray_sdk.core.plugins.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.core.plugins
    :members:
    :undoc-members:
    :show-inheritance:
