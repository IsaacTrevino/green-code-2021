aws\_xray\_sdk.ext.requests package
===================================

Submodules
----------

aws\_xray\_sdk.ext.requests.patch module
----------------------------------------

.. automodule:: aws_xray_sdk.ext.requests.patch
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.ext.requests
    :members:
    :undoc-members:
    :show-inheritance:
