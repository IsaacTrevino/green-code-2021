aws\_xray\_sdk.ext package
==========================

Subpackages
-----------

.. toctree::

    aws_xray_sdk.ext.aiobotocore
    aws_xray_sdk.ext.aiohttp
    aws_xray_sdk.ext.botocore
    aws_xray_sdk.ext.django
    aws_xray_sdk.ext.flask
    aws_xray_sdk.ext.flask_sqlalchemy
    aws_xray_sdk.ext.httplib
    aws_xray_sdk.ext.mysql
    aws_xray_sdk.ext.pynamodb
    aws_xray_sdk.ext.requests
    aws_xray_sdk.ext.sqlalchemy
    aws_xray_sdk.ext.sqlite3

Submodules
----------

aws\_xray\_sdk.ext.boto\_utils module
-------------------------------------

.. automodule:: aws_xray_sdk.ext.boto_utils
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.ext.dbapi2 module
--------------------------------

.. automodule:: aws_xray_sdk.ext.dbapi2
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.ext.util module
------------------------------

.. automodule:: aws_xray_sdk.ext.util
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.ext
    :members:
    :undoc-members:
    :show-inheritance:
