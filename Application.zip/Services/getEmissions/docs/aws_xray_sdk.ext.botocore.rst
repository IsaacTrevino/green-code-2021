aws\_xray\_sdk.ext.botocore package
===================================

Submodules
----------

aws\_xray\_sdk.ext.botocore.patch module
----------------------------------------

.. automodule:: aws_xray_sdk.ext.botocore.patch
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.ext.botocore
    :members:
    :undoc-members:
    :show-inheritance:
