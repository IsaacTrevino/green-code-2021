.. _license:

License
=======

Please see Github page on https://github.com/aws/aws-xray-sdk-python/blob/master/LICENSE.
