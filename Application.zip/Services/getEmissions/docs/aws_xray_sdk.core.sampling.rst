aws\_xray\_sdk.core.sampling package
====================================

Submodules
----------

aws\_xray\_sdk.core.sampling.default\_sampler module
----------------------------------------------------

.. automodule:: aws_xray_sdk.core.sampling.default_sampler
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.sampling.reservoir module
---------------------------------------------

.. automodule:: aws_xray_sdk.core.sampling.reservoir
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.sampling.sampling\_rule module
--------------------------------------------------

.. automodule:: aws_xray_sdk.core.sampling.sampling_rule
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.core.sampling
    :members:
    :undoc-members:
    :show-inheritance:
