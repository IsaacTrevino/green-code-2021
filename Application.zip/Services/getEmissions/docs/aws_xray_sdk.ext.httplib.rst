aws\_xray\_sdk.ext.httplib package
==================================

Submodules
----------

aws\_xray\_sdk.ext.httplib.patch module
---------------------------------------

.. automodule:: aws_xray_sdk.ext.httplib.patch
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.ext.httplib
    :members:
    :undoc-members:
    :show-inheritance:
