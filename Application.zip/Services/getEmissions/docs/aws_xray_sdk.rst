aws\_xray\_sdk package
======================

Subpackages
-----------

.. toctree::

    aws_xray_sdk.core
    aws_xray_sdk.ext

Submodules
----------

aws\_xray\_sdk.version module
-----------------------------

.. automodule:: aws_xray_sdk.version
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk
    :members:
    :undoc-members:
    :show-inheritance:
