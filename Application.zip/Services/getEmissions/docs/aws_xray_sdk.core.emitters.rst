aws\_xray\_sdk.core.emitters package
====================================

Submodules
----------

aws\_xray\_sdk.core.emitters.udp\_emitter module
------------------------------------------------

.. automodule:: aws_xray_sdk.core.emitters.udp_emitter
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.core.emitters
    :members:
    :undoc-members:
    :show-inheritance:
