aws\_xray\_sdk.core.models package
==================================

Submodules
----------

aws\_xray\_sdk.core.models.default\_dynamic\_naming module
----------------------------------------------------------

.. automodule:: aws_xray_sdk.core.models.default_dynamic_naming
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.models.dummy\_entities module
-------------------------------------------------

.. automodule:: aws_xray_sdk.core.models.dummy_entities
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.models.entity module
----------------------------------------

.. automodule:: aws_xray_sdk.core.models.entity
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.models.facade\_segment module
-------------------------------------------------

.. automodule:: aws_xray_sdk.core.models.facade_segment
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.models.http module
--------------------------------------

.. automodule:: aws_xray_sdk.core.models.http
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.models.segment module
-----------------------------------------

.. automodule:: aws_xray_sdk.core.models.segment
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.models.subsegment module
--------------------------------------------

.. automodule:: aws_xray_sdk.core.models.subsegment
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.models.throwable module
-------------------------------------------

.. automodule:: aws_xray_sdk.core.models.throwable
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.models.trace\_header module
-----------------------------------------------

.. automodule:: aws_xray_sdk.core.models.trace_header
    :members:
    :undoc-members:
    :show-inheritance:

aws\_xray\_sdk.core.models.traceid module
-----------------------------------------

.. automodule:: aws_xray_sdk.core.models.traceid
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.core.models
    :members:
    :undoc-members:
    :show-inheritance:
