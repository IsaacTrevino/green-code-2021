aws\_xray\_sdk.ext.pynamodb package
===================================

Submodules
----------

aws\_xray\_sdk.ext.pynamodb.patch module
----------------------------------------

.. automodule:: aws_xray_sdk.ext.pynamodb.patch
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: aws_xray_sdk.ext.pynamodb
    :members:
    :undoc-members:
    :show-inheritance:
