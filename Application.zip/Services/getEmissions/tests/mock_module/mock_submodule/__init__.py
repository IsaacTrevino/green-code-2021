def mock_subinit():
    pass
