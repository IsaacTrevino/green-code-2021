def mock_func():
    pass
