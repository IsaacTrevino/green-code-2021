def mock_init():
    pass
