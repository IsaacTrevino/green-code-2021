import json
import psycopg2
import psycopg2.extras

# conn = psycopg2.connect(database="postgres", user = "postgres", password = "pgPG1223", host = "postgrespublic.cc361kxrjcpb.us-east-1.rds.amazonaws.com", port = "5432")
conn = psycopg2.connect(user="postgres", password="pgPG1223",host="postgrespublic.cc361kxrjcpb.us-east-1.rds.amazonaws.com",port="5432",database="postgres",connect_timeout=5,options='-c statement_timeout=10000')

def lambda_handler(event, context):

    result = []
    cursor = None

    query = "select * from 'Climate'.oecd_water_abstract owa where Year == 2018 and 'Source' = 'Total freshwater' and variable = 'Public water supply' order by yea desc"
    try:
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute(query)
        raw = cursor.fetchall()
        for line in raw:
            result.append(line)
    except:
        print("error")

    return result
