import json
import psycopg2
import psycopg2.extras

# conn = psycopg2.connect(database="postgres", user = "postgres", password = "pgPG1223", host = "postgrespublic.cc361kxrjcpb.us-east-1.rds.amazonaws.com", port = "5432")
conn = psycopg2.connect(user="postgres", password="pgPG1223",host="postgrespublic.cc361kxrjcpb.us-east-1.rds.amazonaws.com",port="5432",database="postgres",connect_timeout=5,options='-c statement_timeout=10000')

def lambda_handler(event, context):
    result = []
    cursor = None

    query = "select \"Facility Name\", geocoord from climate.recycle_data"
    try:
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute(query)
        raw = cursor.fetchall()
        for line in raw:
            result.append(line)
    except Exception as e:
        print("error")
        print(e)
    finally:
        if cursor is not None:
                cursor.close()

    return result
